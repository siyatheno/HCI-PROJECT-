﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    
    public partial class View_Prescription : UserControl
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        public View_Prescription()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf;Integrated Security=True");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Doc_Form_Dashboard login = new Doc_Form_Dashboard();
            this.Hide();
            login.ShowDialog();
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string todaysday;
                todaysday = DateTime.Today.ToShortDateString();
                if (txtPrescriptionNo.Text != "")
                {
                    var query = from o in this.pharmacyDbDataSet.PrescriptionTbl
                                where o.Prescription_ID == Int32.Parse(txtPrescriptionNo.Text)
                                select o;
                    this.prescriptionTblBindingSource.DataSource = query.ToList();
                    dataGridView1.DataSource = query.ToList();
                }
                else if (DateMade.Value > DateTime.MinValue)
                {
                    var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                                where o.Date_Created == DateMade.Value
                                select o;
                    this.prescriptionTblBindingSource.DataSource = query.ToList();
                    dataGridView1.DataSource = query.ToList();
                }
                else if (daterecieved.Value > DateTime.MinValue)
                {
                    var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                                where o.Date_Scheduled == daterecieved.Value
                                select o;
                    this.prescriptionTblBindingSource.DataSource = query.ToList();
                    dataGridView1.DataSource = query.ToList();
                }
                else
                {
                    MessageBox.Show("No Record Found! \n " +
                        "Please Enter value or values to search in the view", "Your Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dataGridView1.Refresh();
                    return;
                }

            }
            catch(Exception wee)
            {
                MessageBox.Show(wee.Message);
                
            }
        }

        private void View_Prescription_Load(object sender, EventArgs e)
        {

            this.prescriptionTblTableAdapter.Fill(this.pharmacyDbDataSet.PrescriptionTbl);
            prescriptionTblBindingSource.DataSource = this.pharmacyDbDataSet.PrescriptionTbl;
        }
    }
}

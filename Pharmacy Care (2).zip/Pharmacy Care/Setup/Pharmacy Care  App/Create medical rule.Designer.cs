﻿
namespace Pharmacy_Care__App
{
    partial class Create_medical_rule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comgender = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comDiagonistic = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Archivo Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(851, 377);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Medical Rule";
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(525, 329);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 33);
            this.button2.TabIndex = 1;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(725, 329);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "Save Product";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Location = new System.Drawing.Point(6, 110);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(507, 261);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Medical Solution Scheme";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.richTextBox1);
            this.groupBox7.Location = new System.Drawing.Point(6, 115);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(495, 137);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Other Medical Scheme";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(4, 21);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(485, 110);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBox5);
            this.groupBox6.Controls.Add(this.checkBox1);
            this.groupBox6.Controls.Add(this.checkBox9);
            this.groupBox6.Controls.Add(this.checkBox4);
            this.groupBox6.Controls.Add(this.checkBox2);
            this.groupBox6.Controls.Add(this.checkBox6);
            this.groupBox6.Controls.Add(this.checkBox8);
            this.groupBox6.Controls.Add(this.checkBox3);
            this.groupBox6.Location = new System.Drawing.Point(6, 24);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(495, 83);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Medical ";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(342, 42);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(64, 19);
            this.checkBox5.TabIndex = 0;
            this.checkBox5.Text = "Other...";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 21);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(103, 19);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Hypellis Ferme";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(115, 42);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(107, 19);
            this.checkBox9.TabIndex = 0;
            this.checkBox9.Text = "Serphia pynalia";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 46);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(99, 19);
            this.checkBox4.TabIndex = 0;
            this.checkBox4.Text = "Termo Gollois";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(115, 21);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(109, 19);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "Vlysnia Commia";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(226, 42);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(92, 19);
            this.checkBox6.TabIndex = 0;
            this.checkBox6.Text = "camelia sylia";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(342, 21);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(103, 19);
            this.checkBox8.TabIndex = 0;
            this.checkBox8.Text = "Herphes Mellis";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(226, 21);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(75, 19);
            this.checkBox3.TabIndex = 0;
            this.checkBox3.Text = "Hollyficis";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Location = new System.Drawing.Point(519, 34);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(326, 289);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Summary Discription";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comgender);
            this.groupBox4.Location = new System.Drawing.Point(246, 34);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(267, 70);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Gender Based";
            // 
            // comgender
            // 
            this.comgender.FormattingEnabled = true;
            this.comgender.Items.AddRange(new object[] {
            "--Select Gender --",
            "Female",
            "Male"});
            this.comgender.Location = new System.Drawing.Point(6, 31);
            this.comgender.Name = "comgender";
            this.comgender.Size = new System.Drawing.Size(255, 23);
            this.comgender.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comDiagonistic);
            this.groupBox2.Location = new System.Drawing.Point(6, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(224, 70);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Diagonistic";
            // 
            // comDiagonistic
            // 
            this.comDiagonistic.FormattingEnabled = true;
            this.comDiagonistic.Items.AddRange(new object[] {
            "--Select Diagonistics --",
            "TB",
            "HIV",
            "AIDS",
            "STI",
            "Cerebral Cancer",
            "Type 2 Cancer",
            "Aesophageal Cancer",
            "Attratis",
            "Kidney Failure",
            "Acquired immunodeficiency syndrome (AIDS)",
            "Alkhurma haemorrhagic fever",
            "Anaplasmosis",
            "Anthrax",
            "Arenavirus",
            "Avian influenza in humans",
            "Babesiosis",
            "Borreliosis",
            "Botulism",
            "Brucellosis",
            "Campylobacteriosis",
            "Chickenpox",
            "Chikungunya virus disease",
            "Chlamydia infection",
            "Cholera",
            "Ciguatera fish poisoning (CFP)",
            "Clostridium difficile infection",
            "Congenital rubella",
            "Congenital syphilis",
            "Coronavirus",
            "COVID-19",
            "Cowpox",
            "Coxsackievirus",
            "Creutzfeldt-Jakob disease",
            "Crimean-Congo haemorrhagic fever",
            "Cryptosporidiosis",
            "Cutaneous warts",
            "Dengue",
            "Diphtheria",
            "Ebola haemorrhagic fever",
            "Echinococcosis",
            "Enteric fever",
            "Enterohaemorrhagic Escherichia coli (EHEC) infection",
            "Enterovirus",
            "Epidemic louse-borne typhus",
            "Escherichia coli infection",
            "Febris recurrens",
            "Food- and waterborne diseases",
            "German measles",
            "Giardiasis",
            "Gonorrhoea",
            "Haemophilus infection",
            "Haemorrhagic fever",
            "Haemorrhagic fever with renal syndrome",
            "Hantavirus infection",
            "Hepatitis",
            "Hepatitis A",
            "Hepatitis B",
            "Hepatitis C",
            "Hepatitis E",
            "HIV infection",
            "Human papillomavirus infection",
            "Hydatidosis",
            "Influenza A (H9N2)",
            "Influenza in humans, avian origin",
            "Influenza in humans, pandemic",
            "Influenza in humans, seasonal",
            "Influenza in humans, swine origin",
            "Invasive Haemophilus influenzae disease",
            "Invasive meningococcal disease",
            "Invasive pneumococcal disease",
            "Japanese encephalitis virus",
            "Lassa fever",
            "Legionnaires’ disease",
            "Leishmaniasis",
            "Leptospirosis",
            "Listeriosis",
            "Louse borne relapsing fever",
            "Louse-borne diseases",
            "Louse-borne typhus",
            "Lyme disease",
            "Lymphogranuloma venereum",
            "Malaria",
            "Marine biotoxins related diseases",
            "Measles",
            "Meningococcal disease",
            "Middle East respiratory syndrome coronavirus",
            "Molecular typing",
            "Monkeypox",
            "Mosquito-borne diseases",
            "Mumps",
            "Nephropathia epidemica",
            "Norovirus infection",
            "Paratyphoid fever",
            "Pertussis",
            "Piroplasmosis",
            "Plague",
            "Pneumococcal disease",
            "Poliomyelitis",
            "fever",
            "Quintan fever",
            "Rabies",
            "Rickettsiosis",
            "Rift Valley fever",
            "Rotavirus infection",
            "Rubella",
            "S. pneumoniae",
            "Salmonellosis",
            "Sandfly-borne diseases",
            "SARS-CoV-2",
            "Schmallenberg virus",
            "Seasonal influenza",
            "Severe acute respiratory syndrome (SARS)",
            "Sexually transmitted infections",
            "Shigellosis",
            "Sindbis fever",
            "Smallpox",
            "Streptococcus pneumoniae",
            "Swine-origin influenza",
            "Syphilis",
            "Syphilis, congenital",
            "Tetanus",
            "Tick-borne diseases",
            "Tick-borne encephalitis (TBE)",
            "Tick-borne relapsing fever",
            "Toxoplasmosis, congenital",
            "Trench fever",
            "Trichinellosis",
            "Tuberculosis",
            "Tularaemia",
            "Typhoid and paratyphoid fever",
            "Vaccine preventable diseases",
            "Variant Creutzfeldt-Jakob disease (vCJD)",
            "Varicella",
            "Viral haemorrhagic fever",
            "Viral hepatitis",
            "West Nile virus infection",
            "Whooping cough",
            "Yellow fever",
            "Yersiniosis"});
            this.comDiagonistic.Location = new System.Drawing.Point(6, 31);
            this.comDiagonistic.Name = "comDiagonistic";
            this.comDiagonistic.Size = new System.Drawing.Size(212, 23);
            this.comDiagonistic.TabIndex = 1;
            this.comDiagonistic.SelectedIndexChanged += new System.EventHandler(this.comDiagonistic_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(17, 21);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(303, 259);
            this.listBox1.TabIndex = 0;
            // 
            // Create_medical_rule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Controls.Add(this.groupBox1);
            this.Name = "Create_medical_rule";
            this.Size = new System.Drawing.Size(851, 377);
            this.Load += new System.EventHandler(this.Create_medical_rule_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comDiagonistic;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comgender;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.ListBox listBox1;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panelDisplay_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuImageButton8_Click(object sender, EventArgs e)
        {
            Login_user wee = new Login_user();
            wee.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want to exit? \n" +
                "unsaved work will not be saved automatically ", "User on Exit ", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.ExitThread();
                Application.Exit();
            }
            else
            {

                this.Refresh();
            }
        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            create_new_account err = new create_new_account();
            this.Hide();
            err.ShowDialog();
            this.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class View_Patient_Appointments : UserControl
    {
        public View_Patient_Appointments()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string todaysday;
            todaysday = DateTime.Today.ToShortDateString();
            if(txtIdentityNum.Text != "")
            {
                var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                            where o.Identity_Number.Contains(txtIdentityNum.Text)
                            select o;
                this.appointmentTblBindingSource.DataSource = query.ToList();
                dataGridView1.DataSource = query.ToList();
            }else if (string.IsNullOrEmpty(txtPersonName.Text) == false)
            {
                var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                            where o.Patients_Name.Contains(txtPersonName.Text)
                            select o;
                this.appointmentTblBindingSource.DataSource = query.ToList();
                dataGridView1.DataSource = query.ToList();
            }else if (DateMade.Value > DateTime.MinValue )
            {
                var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                            where o.Date_Created == DateMade.Value
                            select o;
                this.appointmentTblBindingSource.DataSource = query.ToList();
                dataGridView1.DataSource = query.ToList();
            }
            else if (DateSetAppointment.Value > DateTime.MinValue)
            {
                var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                            where o.Date_Scheduled == DateSetAppointment.Value
                            select o;
                this.appointmentTblBindingSource.DataSource = query.ToList();
                dataGridView1.DataSource = query.ToList();
            }
            else
            {
                MessageBox.Show("No Record Found! \n " +
                    "Please Enter value or values to search in the view", "Your Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataGridView1.Refresh();
                return;
            }
        }

        private void View_Patient_Appointments_Load(object sender, EventArgs e)
        {
            this.appointmentTblTableAdapter.Fill(this.pharmacyDbDataSet.AppointmentTbl);
            appointmentTblBindingSource.DataSource = this.pharmacyDbDataSet.AppointmentTbl;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Patient_Create_New : Form
    {
        SqlCommand cmd;
        SqlConnection con = new SqlConnection();
        public Patient_Create_New()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (string.IsNullOrEmpty(txtFName.Text))
                {
                    MessageBox.Show("Patient Name is required");
                    txtFName.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtLastName.Text))
                {
                    MessageBox.Show("Patient Last Name is required");
                    txtLastName.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtIdNumber.Text))
                {
                    MessageBox.Show("Patient Identity Number is required");
                    txtIdNumber.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtCellphone.Text))
                {
                    MessageBox.Show("Cellphone number is required");
                    txtCellphone.Focus();
                }
                else if (comSpecialisation.SelectedIndex == 0)
                {
                    MessageBox.Show("Gender is required");
                    comSpecialisation.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtNewPassword.Text))
                {
                    MessageBox.Show("New Password is required");
                    txtNewPassword.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtConfirmPass.Text))
                {
                    MessageBox.Show("Confirming password is required");
                    txtConfirmPass.Focus();
                    return;
                }
                else if (txtNewPassword.Text != txtConfirmPass.Text)
                {
                    MessageBox.Show("Passwords Do not match \n " +
                        "Please check your passwords and try again");
                    txtNewPassword.Focus();
                    return;
                }
                else if (txtIdNumber.TextLength != 13)
                {
                    MessageBox.Show("Invalid Identity Number ");
                    txtIdNumber.Focus();
                    return;
                }
                else if (txtCellphone.TextLength != 10)
                {
                    MessageBox.Show("Invalid Cellphone Number ");
                    txtCellphone.Focus();
                    return;
                }
                //alphabet ONLY required validations using regular expressions class
                else if (!Regex.Match(txtFName.Text, "^[a-zA-Z]*$", RegexOptions.IgnoreCase).Success)
                {
                    MessageBox.Show("First Name Should Be only Alphabetic Characters!");
                    txtFName.Focus();
                    return;
                }
                else if (!Regex.Match(txtLastName.Text, "^[a-zA-Z]*$", RegexOptions.IgnoreCase).Success)
                {
                    MessageBox.Show("Last Name Should Be only Alphabetic Characters!");
                    txtLastName.Focus();
                    return;
                }
                else if (txtCellphone.Text.StartsWith("0") == false)
                {
                    MessageBox.Show("Cellphone Number Must start with '0' Zero");
                    txtCellphone.Focus();
                    return;
                }
                else
                {

                    SqlCommand cmd;
                    cmd = new SqlCommand("insert into PatientTbl(Folder_Number, Names,Surname,Identity_Number,Gender,Cellphone,email_Address,Address,Password) values(@Folder_Number,@Names,@Surname,@Identity_Number,@Gender,@Cellphone,@email_Address,@Address,@Password)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Folder_Number", txtPersalID.Text);
                    cmd.Parameters.AddWithValue("@Names", txtFName.Text);
                    cmd.Parameters.AddWithValue("@Surname", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@Identity_Number", txtIdNumber.Text);
                    cmd.Parameters.AddWithValue("@Cellphone", txtCellphone.Text);
                    cmd.Parameters.AddWithValue("@email_Address", txtEMail.Text);
                    cmd.Parameters.AddWithValue("@Gender", comSpecialisation.Text);
                    cmd.Parameters.AddWithValue("@Password", txtConfirmPass.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Patient Account Has been created successfully \n " +
                        "Please save Folder Number you will use it as your username", "Doctor account");
                    this.Hide();
                    Login_user rt = new Login_user();
                    rt.ShowDialog();
                    this.Close();
                }

            }
            catch (Exception ww)
            {
                MessageBox.Show("Something went wrong  \n \n " + ww.Message);
                this.Refresh();
                con.Close();
            }
        }

        private void Patient_Create_New_Load(object sender, EventArgs e)
        {
            comSpecialisation.SelectedIndex = 0;
            Random rand = new Random();
            int minn, maxx, jk;
            minn = 777377;
            maxx = 9923999;
            jk = rand.Next(minn, maxx);
            txtPersalID.Text = jk.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 wee = new Form1();
            this.Hide();
            wee.ShowDialog();
            this.Dispose();

        }
    }
}

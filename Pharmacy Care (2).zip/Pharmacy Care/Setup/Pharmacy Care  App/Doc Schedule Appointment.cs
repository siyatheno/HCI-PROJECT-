﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Doc_Schedule_Appointment : UserControl
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        public Doc_Schedule_Appointment()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void Doc_Schedule_Appointment_Load(object sender, EventArgs e)
        {
            PanelStatus.Visible = false;
            CommentVisibilty();
            this.appointmentTblTableAdapter.Fill(this.pharmacyDbDataSet.AppointmentTbl);
            appointmentTblBindingSource.DataSource = this.pharmacyDbDataSet.AppointmentTbl;
        }
        public void CommentVisibilty()
        {
            btnSubmit.Visible = false;
            txtComment.Visible = false;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            txtComment.Visible = true;
            btnAccept.Enabled = false;
            txtComment.Focus();
        }

        private void txtComment_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtComment.Text))
            {
                btnSubmit.Visible = false;
                return;
            }
            else
            {
                btnSubmit.Visible = true;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PanelStatus.Visible = true;
             cmd = new SqlCommand("select status from AppointmentTbl where Identity_Number = @parm1", con);
             cmd.Parameters.AddWithValue("@parm1",txtIdNUmber.Text); 
            con.Open();
            SqlDataReader reader1;
            reader1 = cmd.ExecuteReader();
            if (reader1.Read())
            {
                var query = from o in this.pharmacyDbDataSet.AppointmentTbl
                            where o.Identity_Number.Contains(txtIdNUmber.Text)
                            select o;
                appointmentTblBindingSource.DataSource = query.ToList();
                dataDisplay.DataSource = query.ToList();
                con.Close();
            }
            else
            {
                MessageBox.Show("No Matches your searches \n " +
                    "Please Clear the fields and try again");
                PanelStatus.Visible = false;
                con.Close();

            }
        }
    

        private void txtComment_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(txtComment, "Enter comment here!");
            toolTip1.ToolTipTitle = "Information";
            toolTip1.UseAnimation = true;

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("update AppointmentTbl set status=@status where Identity_Number = @id  ", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", txtIdNUmber.Text);
                cmd.Parameters.AddWithValue("@status","Declined!");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Appointment Response Has been Sent successfully","Appointment",MessageBoxButtons.OK,MessageBoxIcon.Hand);
                con.Close();
            }catch(Exception we)
            {
                MessageBox.Show(we.Message);
                con.Close();
            }
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("update AppointmentTbl set status=@status where Identity_Number = @id  ", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", txtIdNUmber.Text);
                cmd.Parameters.AddWithValue("@status", "Approved");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Appointment Response Has been Sent successfully", "Appointment", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                con.Close();
            }
            catch (Exception we)
            {
                MessageBox.Show(we.Message);
                con.Close();
            }
        }
    }
}

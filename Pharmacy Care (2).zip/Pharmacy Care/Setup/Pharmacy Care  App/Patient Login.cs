﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Patient_Login : UserControl
    {

        SqlCommand cmd;
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda;
        DataTable dt;
        public Patient_Login()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(txtUsername.Text) | string.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("Username Or Password is not set", "User Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsername.Focus();
                    return;
                }
                else if (txtUsername.Text != "" && txtPassword.Text != "")
                {
                    sda = new SqlDataAdapter("select Count(*) from PatientTbl where Folder_Number ='" + txtUsername.Text + "' and Password = '" + txtPassword.Text + "'", con);
                    dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        //screen to be displaye when login is successfully
                        Patient_dashboard we = new Patient_dashboard();
                        this.Hide();
                        we.ShowDialog();
                        this.Dispose();

                    }
                    else
                    {
                        MessageBox.Show("Login is Unscuccessful \n " +
                        "Username or Password is Invalid", "User login", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }


                }
            }
            catch (Exception AA)
            {
                MessageBox.Show(AA.Message);
                con.Close();

            }


        }
    }
}

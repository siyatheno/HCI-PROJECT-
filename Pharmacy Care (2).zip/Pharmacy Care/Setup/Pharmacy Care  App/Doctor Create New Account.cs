﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Pharmacy_Care__App
{
    public partial class Doctor_Create_New_Account : Form
    {
        SqlCommand cmd;
        SqlConnection con = new SqlConnection();

        public Doctor_Create_New_Account()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }
       
        private void Doctor_Create_New_Account_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            int minn, maxx, jk;
            minn = 77777;
            maxx = 999999;
            jk = rand.Next(minn, maxx);
            txtPersalID.Text = jk.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            try
            {
                if (string.IsNullOrEmpty(txtFName.Text))
                {
                    MessageBox.Show("Doctor Name is required");
                    txtFName.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtLastName.Text))
                {
                    MessageBox.Show("Doctor Last Name is required");
                    txtLastName.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtIdNumber.Text))
                {
                    MessageBox.Show("Doctor Identity Number is required");
                    txtIdNumber.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtCellphone.Text))
                {
                    MessageBox.Show("Cellphone number is required");
                    txtCellphone.Focus();
                }
                else if (comSpecialisation.SelectedIndex == 0)
                {
                    MessageBox.Show("Specialisation is required");
                    comSpecialisation.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtNewPassword.Text))
                {
                    MessageBox.Show("New Password is required");
                    txtNewPassword.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtConfirmPass.Text))
                {
                    MessageBox.Show("Confirming password is required");
                    txtConfirmPass.Focus();
                    return;
                }
                else if (txtNewPassword.Text != txtConfirmPass.Text)
                {
                    MessageBox.Show("Passwords Do not match \n " +
                        "Please check your passwords and try again");
                    txtNewPassword.Focus();
                    return;
                }
                else if (txtIdNumber.TextLength != 13)
                {
                    MessageBox.Show("Invalid Identity Number ");
                    txtIdNumber.Focus();
                    return;
                }
                else if (txtCellphone.TextLength != 10)
                {
                    MessageBox.Show("Invalid Cellphone Number ");
                    txtCellphone.Focus();
                    return;
                }
                //alphabet ONLY required validations using regular expressions class
                else if (!Regex.Match(txtFName.Text, "^[a-zA-Z]*$", RegexOptions.IgnoreCase).Success)
                {
                    MessageBox.Show("First Name Should Be only Alphabetic Characters!");
                    txtFName.Focus();
                    return;
                }
                else if (!Regex.Match(txtLastName.Text, "^[a-zA-Z]*$", RegexOptions.IgnoreCase).Success)
                {
                    MessageBox.Show("Last Name Should Be only Alphabetic Characters!");
                    txtLastName.Focus();
                    return;
                }
                else if (txtCellphone.Text.StartsWith("0") == false)
                {
                    MessageBox.Show("Cellphone Number Must start with '0' Zero");
                    txtCellphone.Focus();
                    return;
                }
                else
                {

                    SqlCommand cmd;
                    cmd = new SqlCommand("insert into DoctorTbl(PersalID, First_Name,Last_Name,Identity_Number,Cellphone,email_Address,Specialisation,Password) values(@PersalID, @First_Name,@Last_Name,@Identity_Number,@Cellphone,@email_Address,@Specialisation,@Password)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@PersalID", txtPersalID.Text);
                    cmd.Parameters.AddWithValue("@First_Name", txtFName.Text);
                    cmd.Parameters.AddWithValue("@Last_Name", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@Identity_Number", txtIdNumber.Text);
                    cmd.Parameters.AddWithValue("@Cellphone", txtCellphone.Text);
                    cmd.Parameters.AddWithValue("@email_Address", txtEMail.Text);
                    cmd.Parameters.AddWithValue("@Specialisation", comSpecialisation.Text);
                    cmd.Parameters.AddWithValue("@Password", txtConfirmPass.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Doctor Account Has been created successfully \n " +
                        "Please save your email address you will use it as your username", "Doctor account");

                    this.Hide();
                    Login_user Solth = new Login_user();
                    Solth.ShowDialog();
                    this.Dispose();
                }

            }
            catch (Exception ww)
            {
                MessageBox.Show("Something went wrong  \n \n " + ww.Message);
                this.Refresh();
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 wee = new Form1();
            this.Hide();
            wee.ShowDialog();
            this.Dispose();

        }
    }
}

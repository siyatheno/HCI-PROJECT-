﻿namespace Pharmacy_Care__App
{
    partial class New_Prescription
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comDiagonistic = new System.Windows.Forms.ComboBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.txtPrescriptionNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comDiagonistic);
            this.groupBox1.Controls.Add(this.txtDate);
            this.groupBox1.Controls.Add(this.txtContent);
            this.groupBox1.Controls.Add(this.txtPrescriptionNo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Archivo Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(851, 377);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Create New Prescription";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(725, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 43);
            this.button1.TabIndex = 8;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comDiagonistic
            // 
            this.comDiagonistic.FormattingEnabled = true;
            this.comDiagonistic.Items.AddRange(new object[] {
            "--Select Diagonistics --",
            "TB",
            "HIV",
            "AIDS",
            "STI",
            "Cerebral Cancer",
            "Type 2 Cancer",
            "Aesophageal Cancer",
            "Attratis",
            "Kidney Failure",
            "Acquired immunodeficiency syndrome (AIDS)",
            "Alkhurma haemorrhagic fever",
            "Anaplasmosis",
            "Anthrax",
            "Arenavirus",
            "Avian influenza in humans",
            "Babesiosis",
            "Borreliosis",
            "Botulism",
            "Brucellosis",
            "Campylobacteriosis",
            "Chickenpox",
            "Chikungunya virus disease",
            "Chlamydia infection",
            "Cholera",
            "Ciguatera fish poisoning (CFP)",
            "Clostridium difficile infection",
            "Congenital rubella",
            "Congenital syphilis",
            "Coronavirus",
            "COVID-19",
            "Cowpox",
            "Coxsackievirus",
            "Creutzfeldt-Jakob disease",
            "Crimean-Congo haemorrhagic fever",
            "Cryptosporidiosis",
            "Cutaneous warts",
            "Dengue",
            "Diphtheria",
            "Ebola haemorrhagic fever",
            "Echinococcosis",
            "Enteric fever",
            "Enterohaemorrhagic Escherichia coli (EHEC) infection",
            "Enterovirus",
            "Epidemic louse-borne typhus",
            "Escherichia coli infection",
            "Febris recurrens",
            "Food- and waterborne diseases",
            "German measles",
            "Giardiasis",
            "Gonorrhoea",
            "Haemophilus infection",
            "Haemorrhagic fever",
            "Haemorrhagic fever with renal syndrome",
            "Hantavirus infection",
            "Hepatitis",
            "Hepatitis A",
            "Hepatitis B",
            "Hepatitis C",
            "Hepatitis E",
            "HIV infection",
            "Human papillomavirus infection",
            "Hydatidosis",
            "Influenza A (H9N2)",
            "Influenza in humans, avian origin",
            "Influenza in humans, pandemic",
            "Influenza in humans, seasonal",
            "Influenza in humans, swine origin",
            "Invasive Haemophilus influenzae disease",
            "Invasive meningococcal disease",
            "Invasive pneumococcal disease",
            "Japanese encephalitis virus",
            "Lassa fever",
            "Legionnaires’ disease",
            "Leishmaniasis",
            "Leptospirosis",
            "Listeriosis",
            "Louse borne relapsing fever",
            "Louse-borne diseases",
            "Louse-borne typhus",
            "Lyme disease",
            "Lymphogranuloma venereum",
            "Malaria",
            "Marine biotoxins related diseases",
            "Measles",
            "Meningococcal disease",
            "Middle East respiratory syndrome coronavirus",
            "Molecular typing",
            "Monkeypox",
            "Mosquito-borne diseases",
            "Mumps",
            "Nephropathia epidemica",
            "Norovirus infection",
            "Paratyphoid fever",
            "Pertussis",
            "Piroplasmosis",
            "Plague",
            "Pneumococcal disease",
            "Poliomyelitis",
            "fever",
            "Quintan fever",
            "Rabies",
            "Rickettsiosis",
            "Rift Valley fever",
            "Rotavirus infection",
            "Rubella",
            "S. pneumoniae",
            "Salmonellosis",
            "Sandfly-borne diseases",
            "SARS-CoV-2",
            "Schmallenberg virus",
            "Seasonal influenza",
            "Severe acute respiratory syndrome (SARS)",
            "Sexually transmitted infections",
            "Shigellosis",
            "Sindbis fever",
            "Smallpox",
            "Streptococcus pneumoniae",
            "Swine-origin influenza",
            "Syphilis",
            "Syphilis, congenital",
            "Tetanus",
            "Tick-borne diseases",
            "Tick-borne encephalitis (TBE)",
            "Tick-borne relapsing fever",
            "Toxoplasmosis, congenital",
            "Trench fever",
            "Trichinellosis",
            "Tuberculosis",
            "Tularaemia",
            "Typhoid and paratyphoid fever",
            "Vaccine preventable diseases",
            "Variant Creutzfeldt-Jakob disease (vCJD)",
            "Varicella",
            "Viral haemorrhagic fever",
            "Viral hepatitis",
            "West Nile virus infection",
            "Whooping cough",
            "Yellow fever",
            "Yersiniosis"});
            this.comDiagonistic.Location = new System.Drawing.Point(458, 56);
            this.comDiagonistic.Name = "comDiagonistic";
            this.comDiagonistic.Size = new System.Drawing.Size(212, 23);
            this.comDiagonistic.TabIndex = 7;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(231, 56);
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(195, 22);
            this.txtDate.TabIndex = 6;
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(6, 120);
            this.txtContent.Multiline = true;
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(664, 120);
            this.txtContent.TabIndex = 6;
            // 
            // txtPrescriptionNo
            // 
            this.txtPrescriptionNo.Location = new System.Drawing.Point(6, 56);
            this.txtPrescriptionNo.Name = "txtPrescriptionNo";
            this.txtPrescriptionNo.ReadOnly = true;
            this.txtPrescriptionNo.Size = new System.Drawing.Size(195, 22);
            this.txtPrescriptionNo.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(464, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Diagnosis";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Prescription Information";
            this.label4.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(233, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Date";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Prescription No";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // New_Prescription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Controls.Add(this.groupBox1);
            this.Name = "New_Prescription";
            this.Size = new System.Drawing.Size(851, 377);
            this.Load += new System.EventHandler(this.New_Prescription_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtPrescriptionNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comDiagonistic;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label label4;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Pharmacy_Care__App
{
    public partial class New_Prescription : UserControl
    {
        SqlCommand cmd;
        SqlConnection con = new SqlConnection();
        public New_Prescription()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void New_Prescription_Load(object sender, EventArgs e)
        {
            comDiagonistic.SelectedIndex = 0;
            Random raa = new Random();
            int  min, maxi, cc;
            min =111111111;
            maxi = 999990099;
            cc = raa.Next(min, maxi);
            txtPrescriptionNo.Text = cc.ToString();
            txtDate.Text = DateTime.Today.ToShortDateString();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (string.IsNullOrEmpty(txtPrescriptionNo.Text))
                {
                    MessageBox.Show("Prescription Number is required");
                    txtPrescriptionNo.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtContent.Text))
                {
                    MessageBox.Show("Prescription information is required");
                    txtContent.Focus();
                    return;
                }
                else
                {

                    SqlCommand cmd;
                    cmd = new SqlCommand("insert into PrescriptionTbl(Prescription_ID,Date_Requested,Diagonisis_Type,Content,Status,DrRecommendations) values(@Prescription_ID,@Date_Requested,@Diagonisis_Type,@Content,@Status,@DrRecommendations)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Prescription_ID", txtPrescriptionNo.Text);
                    cmd.Parameters.AddWithValue("@Date_Requested", DateTime.Today.ToShortDateString());
                    cmd.Parameters.AddWithValue("@Diagonisis_Type", comDiagonistic.SelectedIndex.ToString());
                    cmd.Parameters.AddWithValue("@Content", txtContent.Text);
                    cmd.Parameters.AddWithValue("@Status","Sent");
                    cmd.Parameters.AddWithValue("@DrRecommendations", "Under Examination");
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Prescription Has been created successfully \n ");
                   
                }

            }
            catch (Exception ww)
            {
                MessageBox.Show("Something went wrong  \n \n " + ww.Message);
                this.Refresh();
                con.Close();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}

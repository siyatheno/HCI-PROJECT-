﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Patient_update_Appointment : UserControl
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        public Patient_update_Appointment()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            Update_Constructor ddf = new Update_Constructor();
            ddf.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                MessageBox.Show("Please Enter your ID Number to proceed");
                textBox1.Focus();
            }
            else
            {
                 cmd = new SqlCommand("select Content,email,Contact_Number,Patients_Name,Identity_Number from AppointmentTbl where Identity_Number = @parm1", con);
               cmd.Parameters.AddWithValue("@parm1",textBox1.Text); 
                con.Open();
                SqlDataReader reader1;
                reader1 = cmd.ExecuteReader();
                if (reader1.Read())
                {
                    txtcontent.Text = reader1["Content"].ToString();
                    txtcontact.Text = reader1["Contact_Number"].ToString();
                    txtemail.Text = reader1["email"].ToString();
                    txtid.Text = reader1["Identity_Number"].ToString();
                    txtName.Text = reader1["Patients_Name"].ToString();
                    btnEdit.Enabled = true;
                    con.Close();
                  
                }
                else
                {
                    MessageBox.Show("No record or records matches your Identity number provided \n " +
                        "Please check your ID number and t again.","Update Apointment Failed!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    textBox1.Focus();
                    btnEdit.Enabled = false;
                    con.Close();
                }
            }
        
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            btnSave.Enabled = true;
        }

        private void Patient_update_Appointment_Load(object sender, EventArgs e)
        {
            panel1.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            try
            {

                if (txtcontact.Text != "" && txtName.Text != "")
                {
                    cmd = new SqlCommand("update AppointmentTbl set Content = @Content, email= @email, Contact_Number=@Contact_Number where Identity_Number = @Identity_Number", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Content", txtcontent.Text);
                    cmd.Parameters.AddWithValue("@email", txtemail.Text);
                    cmd.Parameters.AddWithValue("@Identity_Number", txtid.Text);
                    cmd.Parameters.AddWithValue("@Contact_Number", txtcontact.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Appointment Information has been Updated Successfully");
                    con.Close();
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("Please Select Record to Update");
                    con.Close();
                }

            }
            catch (Exception rt)
            {
                MessageBox.Show("System detected error when loading events data \n " +
                  "Please close the window and open it again. \n " +
                  "System Error : \n " +
                  "" + rt.Message);
                con.Close();
                this.Refresh();

            }

        }
    }
}

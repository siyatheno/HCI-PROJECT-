﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Create_medical_rule : UserControl
    {
        SqlCommand cmd;
        SqlConnection con = new SqlConnection();
        public Create_medical_rule()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C: \Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf""; Integrated Security = True; Context Connection = False");
        }

        private void Create_medical_rule_Load(object sender, EventArgs e)
        {
            comDiagonistic.SelectedIndex = 0;
            comgender.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comDiagonistic_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Add("Diagonstic : " + comDiagonistic.SelectedItem.ToString() + "\n ");
           
        }
    }
}

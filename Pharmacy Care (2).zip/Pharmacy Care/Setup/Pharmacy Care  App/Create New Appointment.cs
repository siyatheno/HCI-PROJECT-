﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;
using System.Runtime.Remoting.Contexts;

namespace Pharmacy_Care__App
{
    public partial class Create_New_Appointment : UserControl
    {

        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        public Create_New_Appointment()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtNames.Text =="" || txtNames.Text == "" | txtIdentity.Text == ""| txtContent.Text == ""| txtEMail.Text == "" | txtContactNumber.Text == "")
                {
                    MessageBox.Show("Some of required! are empty \n " +
                        "Please Fill in all required fields to proceed!");
                    return;
                }
                else
                {
                    Random re = new Random();
                    int smallin, maximumIn;
                    smallin = 11100;
                    maximumIn = 99909;
                    int df;
                    df = re.Next(smallin, maximumIn);
                    con.Open();
                    cmd = new SqlCommand("insert into AppointmentTbl(AppointmentCode,Date_Created,Date_Scheduled,Content,status,Patients_Name,email,Contact_Number,Identity_Number) values(@AppointmentCode,@Date_Created,@Date_Scheduled,@Content,@status,@Patients_Name,@email,@Contact_Number,@Identity_Number)", con);
                    cmd.Parameters.AddWithValue("@AppointmentCode", df.ToString());
                    cmd.Parameters.AddWithValue("@Date_Created", DateTime.Today.ToShortDateString());
                    cmd.Parameters.AddWithValue("@Date_Scheduled", DateAppointment.Value.ToShortDateString());
                    cmd.Parameters.AddWithValue("@Content", txtContent.Text);
                    cmd.Parameters.AddWithValue("@status", "Pending");
                    cmd.Parameters.AddWithValue("@Patients_Name", txtNames.Text);
                    cmd.Parameters.AddWithValue("@email", txtEMail.Text);
                    cmd.Parameters.AddWithValue("@Contact_Number", txtContactNumber.Text);
                    cmd.Parameters.AddWithValue("@Identity_Number", txtIdentity.Text);
                    MessageBox.Show("Appointment has been sent Successfully \n " +
                        "Keep on checking your appointment status");
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Login_user we = new Login_user();
                    this.Hide();
                    we.ShowDialog();
                    this.Dispose();
                    
                {
                    MessageBox.Show("Please Provide Details!");
                }
            }
               


            }catch(Exception trt)
            {
                MessageBox.Show(trt.Message);
                con.Close();
                
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Doc_Form_Dashboard : Form
    {
        public Doc_Form_Dashboard()
        {
            InitializeComponent();
        }

        private void Doc_Form_Dashboard_Load(object sender, EventArgs e)
        {
            doctor_dashboard er = new doctor_dashboard();
            panel1.Controls.Clear();
            panel1.Controls.Add(er);
            er.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class create_new_account : Form
    {
        public create_new_account()
        {
            InitializeComponent();
        }

        private void gunaLinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login_user login = new Login_user();
            this.Hide();
            login.ShowDialog();
            this.Dispose();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            Doctor_Create_New_Account login = new Doctor_Create_New_Account();
            this.Hide();
            login.ShowDialog();
            this.Dispose();
        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            Patient_Create_New login = new Patient_Create_New();
            this.Hide();
            login.ShowDialog();
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.ShowDialog();
            this.Dispose();
        }
    }
}

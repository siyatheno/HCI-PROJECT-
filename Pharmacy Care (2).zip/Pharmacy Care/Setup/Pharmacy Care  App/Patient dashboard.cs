﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Patient_dashboard : Form
    {
        public Patient_dashboard()
        {
            InitializeComponent();
        }

        private void bunifuImageButton8_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Unsaved contents will be not saved Automatically \n " +
                "Are you sure you want to EXIT? ", "Exit ", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }else
            {
                this.Refresh();
            }
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {
            Create_New_Appointment ddf = new Create_New_Appointment();
            panedisplay.Controls.Clear();
            panedisplay.Controls.Add(ddf);
            ddf.Show();
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            View_Patient_Appointments ddf = new View_Patient_Appointments();
            panedisplay.Controls.Clear();
            panedisplay.Controls.Add(ddf);
            ddf.Show();
        }

        private void bunifuImageButton7_Click(object sender, EventArgs e)
        {
            View_Prescription_Patient ddf = new View_Prescription_Patient();
            panedisplay.Controls.Clear();
            panedisplay.Controls.Add(ddf);
            ddf.Show();
        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        {


            Patient_update_Appointment erp = new Patient_update_Appointment();
            panedisplay.Controls.Clear();
            panedisplay.Controls.Add(erp);
            erp.Show();
        }

        private void bunifuImageButton6_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton4_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(bunifuImageButton4, "Create new appointment");
        }

        private void bunifuImageButton7_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void bunifuImageButton7_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(bunifuImageButton7, "View Appointments \n " +
                "And downloadable formats");
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {

        }
    }
}
 
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Doctor_Login : UserControl
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter sda;
        public Doctor_Login()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf"";Integrated Security=True;Context Connection=False");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(txtusername.Text) | string.IsNullOrEmpty(txtpassword.Text))
                {
                    MessageBox.Show("Username Or Password is not set", "User Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtusername.Focus();
                    return;
                }
                else if (txtusername.Text != "" && txtpassword.Text != "" )
                {
                    sda = new SqlDataAdapter("select Count(*) from DoctorTbl where email_Address ='" + txtusername.Text + "' and Password = '" + txtpassword.Text + "'", con);
                    dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        //screen to be displaye when login is successfully
                        Doc_Form_Dashboard we = new Doc_Form_Dashboard();
                        this.Hide();
                        we.ShowDialog();
                        this.Dispose();
                        
                    }
                    else
                    {
                        MessageBox.Show("Login is Unscuccessful \n " +
                        "Username or Password is Invalid", "User login", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }


                }
            }
            catch (Exception AA)
            {
                MessageBox.Show(AA.Message);
                con.Close();

            }
            
        }
    }
}

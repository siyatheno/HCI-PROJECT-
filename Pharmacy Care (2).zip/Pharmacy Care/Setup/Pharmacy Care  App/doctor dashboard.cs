﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class doctor_dashboard : UserControl
    {
        string todays;
        SqlCommand cmd;
        SqlConnection con = new SqlConnection();

        
        public doctor_dashboard()
        {
            InitializeComponent();
            con.ConnectionString = (@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C: \Users\PAYETIC_DER_HACKxx\Desktop\Pharmacy Care\Setup\Pharmacy Care  App\PharmacyDb.mdf""; Integrated Security = True; Context Connection = False");
        }

        private void lblDate_Click(object sender, EventArgs e)
        {
            todays = DateTime.Today.ToString("dd/MM/yyyy");
            lblDate.Text = todays;
        }

        private void doctor_dashboard_Load(object sender, EventArgs e)
        {
            todays = DateTime.Today.ToString("dd/MM/yyyy");
            lblDate.Text = todays;
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            Doc_Schedule_Appointment  err = new Doc_Schedule_Appointment();
            panelDocDisplay.Controls.Clear();
            panelDocDisplay.Controls.Add(err);
            err.Show();
        }

        private void btnNewMedication_Click(object sender, EventArgs e)
        {
            Create_medical_rule err = new Create_medical_rule();
            panelDocDisplay.Controls.Clear();
            panelDocDisplay.Controls.Add(err);
            err.Show();
        }

        private void btnViewPatientsComments_Click(object sender, EventArgs e)
        {
            //create new Prescription
            New_Prescription err = new New_Prescription();
            panelDocDisplay.Controls.Clear();
            panelDocDisplay.Controls.Add(err);
            err.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void gunaLinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login_user wee = new Login_user();
            this.Hide();
            wee.ShowDialog();
            this.Dispose();
        }
    }
}

﻿
namespace Pharmacy_Care__App
{
    partial class doctor_dashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.gunaLinkLabel2 = new Guna.UI.WinForms.GunaLinkLabel();
            this.gunaLinkLabel1 = new Guna.UI.WinForms.GunaLinkLabel();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHelp = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnViewPatientsComments = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnMedicationRuleView = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnViewAppointment = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnNewMedication = new Bunifu.Framework.UI.BunifuImageButton();
            this.button1 = new System.Windows.Forms.Button();
            this.panelDocDisplay = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHelp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnViewPatientsComments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMedicationRuleView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnViewAppointment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewMedication)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 91);
            this.panel1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.gunaVSeparator1);
            this.groupBox1.Controls.Add(this.gunaLinkLabel2);
            this.groupBox1.Controls.Add(this.gunaLinkLabel1);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnHelp);
            this.groupBox1.Controls.Add(this.btnViewPatientsComments);
            this.groupBox1.Controls.Add(this.btnMedicationRuleView);
            this.groupBox1.Controls.Add(this.btnViewAppointment);
            this.groupBox1.Controls.Add(this.btnNewMedication);
            this.groupBox1.Location = new System.Drawing.Point(6, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(845, 83);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Main Menu";
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(635, 16);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(10, 56);
            this.gunaVSeparator1.TabIndex = 0;
            // 
            // gunaLinkLabel2
            // 
            this.gunaLinkLabel2.AutoSize = true;
            this.gunaLinkLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLinkLabel2.Location = new System.Drawing.Point(657, 29);
            this.gunaLinkLabel2.Name = "gunaLinkLabel2";
            this.gunaLinkLabel2.Size = new System.Drawing.Size(41, 15);
            this.gunaLinkLabel2.TabIndex = 2;
            this.gunaLinkLabel2.TabStop = true;
            this.gunaLinkLabel2.Text = "Profile";
            // 
            // gunaLinkLabel1
            // 
            this.gunaLinkLabel1.AutoSize = true;
            this.gunaLinkLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLinkLabel1.Location = new System.Drawing.Point(758, 29);
            this.gunaLinkLabel1.Name = "gunaLinkLabel1";
            this.gunaLinkLabel1.Size = new System.Drawing.Size(45, 15);
            this.gunaLinkLabel1.TabIndex = 2;
            this.gunaLinkLabel1.TabStop = true;
            this.gunaLinkLabel1.Text = "Logout";
            this.gunaLinkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.gunaLinkLabel1_LinkClicked);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Archivo Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(726, 58);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(73, 15);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "dd/mm/YYYY";
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Archivo Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(657, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "DATE : ";
            // 
            // btnHelp
            // 
            this.btnHelp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnHelp.Image = global::Pharmacy_Care__App.Properties.Resources.inquiry_30px;
            this.btnHelp.ImageActive = null;
            this.btnHelp.Location = new System.Drawing.Point(541, 28);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(79, 44);
            this.btnHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnHelp.TabIndex = 0;
            this.btnHelp.TabStop = false;
            this.btnHelp.Zoom = 10;
            // 
            // btnViewPatientsComments
            // 
            this.btnViewPatientsComments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnViewPatientsComments.Image = global::Pharmacy_Care__App.Properties.Resources.request;
            this.btnViewPatientsComments.ImageActive = null;
            this.btnViewPatientsComments.Location = new System.Drawing.Point(415, 29);
            this.btnViewPatientsComments.Name = "btnViewPatientsComments";
            this.btnViewPatientsComments.Size = new System.Drawing.Size(79, 44);
            this.btnViewPatientsComments.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnViewPatientsComments.TabIndex = 0;
            this.btnViewPatientsComments.TabStop = false;
            this.btnViewPatientsComments.Zoom = 10;
            this.btnViewPatientsComments.Click += new System.EventHandler(this.btnViewPatientsComments_Click);
            // 
            // btnMedicationRuleView
            // 
            this.btnMedicationRuleView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnMedicationRuleView.Image = global::Pharmacy_Care__App.Properties.Resources.New_Event;
            this.btnMedicationRuleView.ImageActive = null;
            this.btnMedicationRuleView.Location = new System.Drawing.Point(289, 29);
            this.btnMedicationRuleView.Name = "btnMedicationRuleView";
            this.btnMedicationRuleView.Size = new System.Drawing.Size(79, 44);
            this.btnMedicationRuleView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMedicationRuleView.TabIndex = 0;
            this.btnMedicationRuleView.TabStop = false;
            this.btnMedicationRuleView.Zoom = 10;
            this.btnMedicationRuleView.Click += new System.EventHandler(this.bunifuImageButton4_Click);
            // 
            // btnViewAppointment
            // 
            this.btnViewAppointment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnViewAppointment.Image = global::Pharmacy_Care__App.Properties.Resources.book_search;
            this.btnViewAppointment.ImageActive = null;
            this.btnViewAppointment.Location = new System.Drawing.Point(163, 28);
            this.btnViewAppointment.Name = "btnViewAppointment";
            this.btnViewAppointment.Size = new System.Drawing.Size(79, 44);
            this.btnViewAppointment.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnViewAppointment.TabIndex = 0;
            this.btnViewAppointment.TabStop = false;
            this.btnViewAppointment.Zoom = 10;
            this.btnViewAppointment.Click += new System.EventHandler(this.bunifuImageButton3_Click);
            // 
            // btnNewMedication
            // 
            this.btnNewMedication.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnNewMedication.Image = global::Pharmacy_Care__App.Properties.Resources.Add_new;
            this.btnNewMedication.ImageActive = null;
            this.btnNewMedication.Location = new System.Drawing.Point(37, 28);
            this.btnNewMedication.Name = "btnNewMedication";
            this.btnNewMedication.Size = new System.Drawing.Size(79, 44);
            this.btnNewMedication.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnNewMedication.TabIndex = 0;
            this.btnNewMedication.TabStop = false;
            this.btnNewMedication.Zoom = 10;
            this.btnNewMedication.Click += new System.EventHandler(this.btnNewMedication_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(4, 478);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "<< Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelDocDisplay
            // 
            this.panelDocDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDocDisplay.Location = new System.Drawing.Point(1, 95);
            this.panelDocDisplay.Name = "panelDocDisplay";
            this.panelDocDisplay.Size = new System.Drawing.Size(851, 377);
            this.panelDocDisplay.TabIndex = 2;
            // 
            // doctor_dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Controls.Add(this.panelDocDisplay);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Name = "doctor_dashboard";
            this.Size = new System.Drawing.Size(856, 526);
            this.Load += new System.EventHandler(this.doctor_dashboard_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHelp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnViewPatientsComments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMedicationRuleView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnViewAppointment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNewMedication)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label1;
        public Bunifu.Framework.UI.BunifuImageButton btnHelp;
        public Bunifu.Framework.UI.BunifuImageButton btnViewPatientsComments;
        public Bunifu.Framework.UI.BunifuImageButton btnMedicationRuleView;
        public Bunifu.Framework.UI.BunifuImageButton btnViewAppointment;
        public Bunifu.Framework.UI.BunifuImageButton btnNewMedication;
        private System.Windows.Forms.Button button1;
        private Guna.UI.WinForms.GunaLinkLabel gunaLinkLabel2;
        private Guna.UI.WinForms.GunaLinkLabel gunaLinkLabel1;
        private System.Windows.Forms.Panel panelDocDisplay;
        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class Login_user : Form
    {
        public Login_user()
        {
            InitializeComponent();
        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            pandelShow.Controls.Clear();
            Patient_Login login = new Patient_Login();
            pandelShow.Controls.Add(login);
            login.Show();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            pandelShow.Controls.Clear();
            Doctor_Login login = new Doctor_Login();
            pandelShow.Controls.Add(login);
            login.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            create_new_account newAccounthandler = new create_new_account();
            newAccounthandler.ShowDialog();
            this.Dispose();
            /*!-- Allow @Override*/
        }
    }
}

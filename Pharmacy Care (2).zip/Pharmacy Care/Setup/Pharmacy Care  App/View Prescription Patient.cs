﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Care__App
{
    public partial class View_Prescription_Patient : UserControl
    {
        public View_Prescription_Patient()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void View_Prescription_Patient_Load(object sender, EventArgs e)
        {
            this.prescriptionTblTableAdapter.Fill(this.pharmacyDbDataSet.PrescriptionTbl);
            prescriptionTblBindingSource.DataSource = this.pharmacyDbDataSet.PrescriptionTbl;
        }
    }
}
